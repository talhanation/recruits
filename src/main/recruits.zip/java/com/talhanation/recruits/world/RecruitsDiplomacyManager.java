package com.talhanation.recruits.world;

import com.talhanation.recruits.DiplomacyEvent;
import com.talhanation.recruits.FactionEvents;
import com.talhanation.recruits.Main;
import com.talhanation.recruits.network.MessageToClientSetDiplomaticToast;
import com.talhanation.recruits.network.MessageToClientUpdateDiplomacyList;
import com.talhanation.recruits.network.MessageToClientUpdateEmbargoes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.network.PacketDistributor;

import java.util.*;

public class RecruitsDiplomacyManager {

    // -------------------------------------------------------------------------
    // Diplomacy (team <-> team)
    // -------------------------------------------------------------------------

    public Map<String, Map<String, DiplomacyStatus>> diplomacyMap = new HashMap<>();

    public void load(ServerLevel level) {
        RecruitsDiplomacySaveData data = RecruitsDiplomacySaveData.get(level);
        diplomacyMap = data.getDiplomacyMap();
        embargoMap   = data.getEmbargoMap();
    }

    public void save(ServerLevel level) {
        RecruitsDiplomacySaveData data = RecruitsDiplomacySaveData.get(level);

        for (Map.Entry<String, Map<String, DiplomacyStatus>> entry : diplomacyMap.entrySet()) {
            String team = entry.getKey();
            Map<String, DiplomacyStatus> relations = entry.getValue();
            for (Map.Entry<String, DiplomacyStatus> relationEntry : relations.entrySet()) {
                data.setRelation(team, relationEntry.getKey(), relationEntry.getValue().getByteValue());
            }
        }

        data.setDirty();
        this.broadcastDiplomacyMapToAll(level);
    }

    public void setRelation(String team, String otherTeam, DiplomacyStatus relation, ServerLevel level){
        this.setRelation(team, otherTeam, relation, level, true);
    }

    public void setRelation(String team, String otherTeam, DiplomacyStatus relation, ServerLevel level, boolean notifyPlayers) {
        DiplomacyStatus currentRelation = this.getRelation(team, otherTeam);

        if (currentRelation == relation) return;

        DiplomacyEvent.RelationChanged relEvent =
                new DiplomacyEvent.RelationChanged(team, otherTeam, level, currentRelation, relation);
        if (MinecraftForge.EVENT_BUS.post(relEvent)) return;

        diplomacyMap.computeIfAbsent(team, k -> new HashMap<>()).put(otherTeam, relation);
        if (notifyPlayers) this.notifyPlayersInTeam(team, otherTeam, relation, level);

        this.save(level);
    }

    public DiplomacyStatus getRelation(String team, String otherTeam) {
        return diplomacyMap.getOrDefault(team, new HashMap<>()).getOrDefault(otherTeam, DiplomacyStatus.NEUTRAL);
    }

    public enum DiplomacyStatus {
        NEUTRAL((byte) 0),
        ALLY((byte) 1),
        ENEMY((byte) 2);

        private final byte byteValue;

        DiplomacyStatus(byte byteValue) {
            this.byteValue = byteValue;
        }

        public byte getByteValue() {
            return byteValue;
        }

        public static DiplomacyStatus fromByte(byte value) {
            return switch (value) {
                case 1 -> ALLY;
                case 2 -> ENEMY;
                default -> NEUTRAL;
            };
        }
    }

    public void notifyPlayersInTeam(String teamName, String otherTeamName, DiplomacyStatus relation, ServerLevel level) {
        RecruitsFaction team = FactionEvents.recruitsFactionManager.getFactionByStringID(teamName);
        RecruitsFaction otherTeam = FactionEvents.recruitsFactionManager.getFactionByStringID(otherTeamName);

        if(team != null && otherTeam != null){
            List<ServerPlayer> playersInTeam = FactionEvents.recruitsFactionManager.getPlayersInTeam(team.getStringID(), level);
            for (ServerPlayer player : playersInTeam) {
                Main.SIMPLE_CHANNEL.send(PacketDistributor.PLAYER.with(()-> player), new MessageToClientSetDiplomaticToast(relation.getByteValue(), otherTeam));
            }
            List<ServerPlayer> playersInTeam2 = FactionEvents.recruitsFactionManager.getPlayersInTeam(otherTeam.getStringID(), level);
            for (ServerPlayer player : playersInTeam2) {
                Main.SIMPLE_CHANNEL.send(PacketDistributor.PLAYER.with(()-> player), new MessageToClientSetDiplomaticToast(relation.getByteValue() + 4, team));
            }
        }
    }
    public static CompoundTag mapToNbt(Map<String, Map<String, RecruitsDiplomacyManager.DiplomacyStatus>> diplomacyMap) {
        CompoundTag nbt = new CompoundTag();

        diplomacyMap.forEach((team, relations) -> {
            CompoundTag teamTag = new CompoundTag();
            relations.forEach((otherTeam, status) -> teamTag.putByte(otherTeam, status.getByteValue()));
            nbt.put(team, teamTag);
        });
        return nbt;
    }

    public static Map<String, Map<String, RecruitsDiplomacyManager.DiplomacyStatus>> mapFromNbt(CompoundTag nbt) {
        Map<String, Map<String, RecruitsDiplomacyManager.DiplomacyStatus>> diplomacyMap = new HashMap<>();

        for (String team : nbt.getAllKeys()) {
            CompoundTag teamTag = nbt.getCompound(team);
            Map<String, DiplomacyStatus> relations = new HashMap<>();
            for (String otherTeam : teamTag.getAllKeys()) {
                byte statusByte = teamTag.getByte(otherTeam);
                relations.put(otherTeam, DiplomacyStatus.fromByte(statusByte));
            }
            diplomacyMap.put(team, relations);
        }
        return diplomacyMap;
    }

    public void broadcastDiplomacyMapToPlayer(Player player) {
        if (player == null) return;
        Main.SIMPLE_CHANNEL.send(PacketDistributor.PLAYER.with(() -> (ServerPlayer) player),
                new MessageToClientUpdateDiplomacyList(diplomacyMap));
    }

    public void broadcastDiplomacyMapToAll(ServerLevel serverLevel) {
        if (serverLevel == null) return;
        for (ServerPlayer serverPlayer : serverLevel.players()) {
            Main.SIMPLE_CHANNEL.send(PacketDistributor.PLAYER.with(() -> serverPlayer),
                    new MessageToClientUpdateDiplomacyList(diplomacyMap));
        }
    }

    // -------------------------------------------------------------------------
    // Embargo (player UUID -> set of embargoed teamIDs)
    // -------------------------------------------------------------------------

    /** Key: playerUUID as String. Value: set of embargoed faction stringIDs. */
    public Map<UUID, String> embargoMap = new HashMap<>();

    /**
     * Adds an embargo for {@code playerUUID} against {@code teamID}.
     * Silently ignored if {@code teamID} is the player's own faction.
     */
    public void addEmbargo(UUID playerUUID, String teamID, ServerLevel level) {
        String current = embargoMap.get(playerUUID);
        current = current + teamID +",";
        embargoMap.put(playerUUID, current);

        saveEmbargo(level);
    }

    /** Removes a single embargo entry. */
    public void removeEmbargo(UUID playerUUID, String teamID, ServerLevel level) {
        Set<String> set = embargoMap.get(playerUUID.toString());
        if (set != null) {
            set.remove(teamID);
            if (set.isEmpty()) embargoMap.remove(playerUUID.toString());
        }
        saveEmbargo(level);
    }

    /**
     * Returns {@code true} if {@code playerUUID} has an active embargo
     * against {@code teamID}.
     */
    public boolean hasEmbargo(UUID playerUUID, String teamID) {
        String embargoes = embargoMap.get(playerUUID);
        return embargoes != null && embargoes.contains(teamID);
    }

    /** Returns all embargoed teamIDs for the given player, or an empty set. */
    public String getEmbargoedTeams(UUID playerUUID) {
        return embargoMap.getOrDefault(playerUUID,"");
    }

    /** Persists the embargo map and broadcasts the update to all online players. */
    public void saveEmbargo(ServerLevel level) {
        RecruitsDiplomacySaveData data = RecruitsDiplomacySaveData.get(level);
        data.setEmbargoMap(embargoMap);
        data.setDirty();
        broadcastEmbargoesToAll(level);
    }

    public void broadcastEmbargoesToPlayer(Player player) {
        if (player == null) return;
        Main.SIMPLE_CHANNEL.send(PacketDistributor.PLAYER.with(() -> (ServerPlayer) player),
                new MessageToClientUpdateEmbargoes(embargoMap));
    }

    public void broadcastEmbargoesToAll(ServerLevel serverLevel) {
        if (serverLevel == null) return;
        for (ServerPlayer serverPlayer : serverLevel.players()) {
            Main.SIMPLE_CHANNEL.send(PacketDistributor.PLAYER.with(() -> serverPlayer),
                    new MessageToClientUpdateEmbargoes(embargoMap));
        }
    }

    // -- NBT helpers ----------------------------------------------------------

    public static CompoundTag embargoMapToNbt(Map<UUID, String> map) {
        CompoundTag nbt = new CompoundTag();
        map.forEach((uuidKey, teamIDs) -> {
            if (!teamIDs.isEmpty()) {
                nbt.putString());
            }
        });
        return nbt;
    }

    public static Map<String, Set<String>> embargoMapFromNbt(CompoundTag nbt) {
        Map<String, Set<String>> map = new HashMap<>();
        for (String key : nbt.getAllKeys()) {
            String csv = nbt.getString(key);
            if (!csv.isEmpty()) {
                map.put(key, new HashSet<>(Arrays.asList(csv.split(","))));
            }
        }
        return map;
    }
}
