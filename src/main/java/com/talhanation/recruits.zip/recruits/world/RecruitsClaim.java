package com.talhanation.recruits.world;
import com.talhanation.recruits.ClaimEvents;
import com.talhanation.recruits.FactionEvents;
import com.talhanation.recruits.SiegeEvent;
import net.minecraftforge.common.MinecraftForge;
import com.talhanation.recruits.config.RecruitsServerConfig;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ChunkPos;

import java.util.*;

public class RecruitsClaim {

    private final UUID uuid;
    private final List<ChunkPos> claimedChunks = new ArrayList<>();
    private String name;
    private RecruitsFaction ownerFaction;
    private boolean allowBlockInteraction = false;
    private boolean allowBlockPlacement   = false;
    private boolean allowBlockBreaking    = false;
    public List<RecruitsFaction> defendingParties = new ArrayList<>();
    public List<RecruitsFaction> attackingParties = new ArrayList<>();
    public ChunkPos center;
    public boolean isUnderSiege;
    public int health;
    /** Prozentuale Siege-Geschwindigkeit (0.0 = pausiert, 1.0 = normal, 2.0 = +100%). Serverseitig berechnet, zum Client synchronisiert. */
    public float siegeSpeedPercent;
    public RecruitsPlayerInfo playerInfo;
    public boolean isAdmin;
    public boolean isRemoved;
    public static final int DEFAULT_MAX_SIZE = 50;
    public RecruitsClaim(String name, RecruitsFaction ownerFaction) {
        this.uuid = UUID.randomUUID();
        this.name = name;
        this.ownerFaction = ownerFaction;
        this.isAdmin = false;
        resetHealth();
    }

    private RecruitsClaim(UUID uuid, String name, RecruitsFaction ownerFaction){
        this.uuid = uuid;
        this.name = name;
        this.ownerFaction = ownerFaction;
        this.isAdmin = false;
    }

    public static RecruitsClaim fromNetwork(UUID uuid, String name, RecruitsFaction ownerFaction) {
        return new RecruitsClaim(uuid, name, ownerFaction);
    }

    public RecruitsClaim(RecruitsFaction faction) {
        this(faction.getTeamDisplayName(), faction);
    }

    public UUID getUUID() {
        return uuid;
    }

    public void setCenter(ChunkPos center){
        this.center = center;
    }

    public ChunkPos getCenter(){
        return this.center;
    }
    public void addChunk(ChunkPos chunkPos) {
        if (chunkPos != null && !claimedChunks.contains(chunkPos)) {
            claimedChunks.add(chunkPos);
        }
    }

    public void removeChunk(ChunkPos chunkPos) {
        claimedChunks.remove(chunkPos);
    }

    public boolean containsChunk(ChunkPos chunkPos) {
        return claimedChunks.contains(chunkPos);
    }

    public List<ChunkPos> getClaimedChunks() {
        return claimedChunks;
    }

    public String getName() {
        return name;
    }

    public String getOwnerFactionStringID() {
        return ownerFaction.getStringID();
    }
    public RecruitsFaction getOwnerFaction(){
        return ownerFaction;
    }
    public RecruitsPlayerInfo getPlayerInfo(){
        return playerInfo;
    }
    public boolean isBlockInteractionAllowed() {
        return allowBlockInteraction;
    }

    public boolean isBlockPlacementAllowed() {
        return allowBlockPlacement;
    }

    public boolean isBlockBreakingAllowed() {
        return allowBlockBreaking;
    }

    public void setName(String name) {
        this.name = name;
    }
    public void setAdminClaim(boolean admin){
        this.isAdmin = admin;
    }
    public void setOwnerFaction(RecruitsFaction faction) {
        this.ownerFaction = faction;
    }
    public void setPlayer(RecruitsPlayerInfo playerInfo) {
        this.playerInfo = playerInfo;
    }
    public void setBlockInteractionAllowed(boolean allow) {
        this.allowBlockInteraction = allow;
    }

    public void setBlockPlacementAllowed(boolean allow) {
        this.allowBlockPlacement = allow;
    }

    public void setBlockBreakingAllowed(boolean allow) {
        this.allowBlockBreaking = allow;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public float getSiegeSpeedPercent() {
        return siegeSpeedPercent;
    }

    public void setSiegeSpeedPercent(float siegeSpeedPercent) {
        this.siegeSpeedPercent = siegeSpeedPercent;
    }

    @Override
    public String toString() {
        return this.getName();
    }

    public CompoundTag toNBT() {
        CompoundTag nbt = new CompoundTag();
        nbt.putUUID("UUID", this.uuid);
        nbt.putString("name", name);
        if (ownerFaction != null) nbt.put("ownerFaction", ownerFaction.toNBT());
        if (playerInfo != null) nbt.put("playerInfo", playerInfo.toNBT());
        nbt.putBoolean("allowInteraction", allowBlockInteraction);
        nbt.putBoolean("allowPlacement", allowBlockPlacement);
        nbt.putBoolean("allowBreaking", allowBlockBreaking);
        nbt.putBoolean("isAdmin", isAdmin);
        nbt.putBoolean("isUnderSiege", isUnderSiege);
        nbt.putBoolean("isRemoved", isRemoved);
        // Claimed Chunks
        ListTag chunkList = new ListTag();
        for (ChunkPos pos : claimedChunks) {
            CompoundTag chunkTag = new CompoundTag();
            chunkTag.putInt("x", pos.x);
            chunkTag.putInt("z", pos.z);
            chunkList.add(chunkTag);
        }
        nbt.put("chunks", chunkList);

        nbt.putInt("centerX", this.getCenter().x);
        nbt.putInt("centerZ", this.getCenter().z);
        nbt.putInt("health", this.getHealth());
        nbt.putFloat("siegeSpeedPercent", this.getSiegeSpeedPercent());

        // Defending Parties
        ListTag defendingList = new ListTag();
        if(defendingParties != null && !defendingParties.isEmpty()){
            for (RecruitsFaction team : defendingParties) {
                if(team != null) defendingList.add(team.toNBT());
            }
        }
        nbt.put("defendingParties", defendingList);

        // Attacking Parties
        ListTag attackingList = new ListTag();
        if(attackingParties != null && !attackingParties.isEmpty()){
            for (RecruitsFaction team : attackingParties) {
                if(team != null) attackingList.add(team.toNBT());
            }
        }

        nbt.put("attackingParties", attackingList);

        return nbt;
    }

    public static RecruitsClaim fromNBT(CompoundTag nbt) {
        UUID uuid = nbt.getUUID("UUID");
        String name = nbt.getString("name");
        RecruitsFaction recruitsFaction = RecruitsFaction.fromNBT(nbt.getCompound("ownerFaction"));
        RecruitsClaim claim = new RecruitsClaim(uuid, name, recruitsFaction);
        RecruitsPlayerInfo playerInfo = RecruitsPlayerInfo.getFromNBT(nbt.getCompound("playerInfo"));
        if (playerInfo != null) claim.setPlayer(playerInfo);


        claim.setBlockInteractionAllowed(nbt.getBoolean("allowInteraction"));
        claim.setBlockPlacementAllowed(nbt.getBoolean("allowPlacement"));
        claim.setBlockBreakingAllowed(nbt.getBoolean("allowBreaking"));
        claim.setAdminClaim(nbt.getBoolean("isAdmin"));
        claim.isUnderSiege = nbt.getBoolean("isUnderSiege");
        claim.isRemoved = nbt.getBoolean("isRemoved");

        if (nbt.contains("chunks", Tag.TAG_LIST)) {
            ListTag chunkList = nbt.getList("chunks", Tag.TAG_COMPOUND);
            for (Tag tag : chunkList) {
                CompoundTag chunkTag = (CompoundTag) tag;
                int x = chunkTag.getInt("x");
                int z = chunkTag.getInt("z");
                claim.addChunk(new ChunkPos(x, z));
            }
        }

        int x = nbt.getInt("centerX");
        int z = nbt.getInt("centerZ");
        claim.setCenter(new ChunkPos(x, z));

        claim.setHealth(nbt.getInt("health"));
        claim.setSiegeSpeedPercent(nbt.getFloat("siegeSpeedPercent"));

        // Defending Parties
        if (nbt.contains("defendingParties", Tag.TAG_LIST)) {
            ListTag defendingList = nbt.getList("defendingParties", Tag.TAG_COMPOUND);
            for (Tag tag : defendingList) {
                claim.defendingParties.add(RecruitsFaction.fromNBT((CompoundTag) tag));
            }
        }

        // Attacking Parties
        if (nbt.contains("attackingParties", Tag.TAG_LIST)) {
            ListTag attackingList = nbt.getList("attackingParties", Tag.TAG_COMPOUND);
            for (Tag tag : attackingList) {
                claim.attackingParties.add(RecruitsFaction.fromNBT((CompoundTag) tag));
            }
        }

        return claim;
    }


    public static CompoundTag toNBT(List<RecruitsClaim> list) {
        CompoundTag nbt = new CompoundTag();
        ListTag claimList = new ListTag();

        for (RecruitsClaim claim : list) {
            claimList.add(claim.toNBT());
        }

        nbt.put("Claims", claimList);
        return nbt;
    }

    public static List<RecruitsClaim> getListFromNBT(CompoundTag nbt) {
        List<RecruitsClaim> list = new ArrayList<>();
        ListTag claimList = nbt.getList("Claims", Tag.TAG_COMPOUND);

        for (int i = 0; i < claimList.size(); i++) {
            CompoundTag claimTag = claimList.getCompound(i);
            RecruitsClaim claim = RecruitsClaim.fromNBT(claimTag);
            list.add(claim);
        }

        return list;
    }

    public void setSiegeSuccess(ServerLevel level){
        for(Player player : FactionEvents.recruitsFactionManager.getPlayersInTeam(this.getOwnerFactionStringID(), level)){
            player.sendSystemMessage(SIEGE_SUCCESS_DEFENDER(this.getName()));
        }
        if(attackingParties == null || attackingParties.isEmpty()) return;

        RecruitsFaction recruitsFaction = attackingParties.get(0);

        if(recruitsFaction == null) return;

        this.setOwnerFaction(recruitsFaction);
        this.setPlayer(new RecruitsPlayerInfo(recruitsFaction.getTeamLeaderUUID(), recruitsFaction.getTeamLeaderName(), recruitsFaction));
        this.isUnderSiege = false;
        this.resetHealth();

        for(Player player : FactionEvents.recruitsFactionManager.getPlayersInTeam(this.getOwnerFactionStringID(), level)){
            player.sendSystemMessage(SIEGE_SUCCESS_ATTACKER(this.getName()));
        }

        this.attackingParties.clear();
        this.defendingParties.clear();

        // SiegeEvent.Success feuern – Besitz wurde bereits übertragen
        MinecraftForge.EVENT_BUS.post(new SiegeEvent.Success(this, level));
    }

    public void resetHealth() {
        this.health = getMaxHealth();
    }

    public int getMaxHealth(){
        return 60 * RecruitsServerConfig.SiegeClaimsConquerTime.get();
    }
    public void setUnderSiege(boolean newState, ServerLevel level) {
        if (this.isUnderSiege == newState) return;

        RecruitsFaction owner = getOwnerFaction();

        if (owner == null) return;

        if (newState) {
            // SiegeEvent.Start feuern – cancelable, damit andere Mods/Config den Start verhindern können
            SiegeEvent.Start startEvent = new SiegeEvent.Start(this, level);
            MinecraftForge.EVENT_BUS.post(startEvent);
            if (startEvent.isCanceled()) return;

            startSiege(owner, level);
        } else {
            endSiege(owner, level);
            MinecraftForge.EVENT_BUS.post(new SiegeEvent.End(this, level));
        }

        this.isUnderSiege = newState;
    }
    private void startSiege(RecruitsFaction owner, ServerLevel level) {
        notifyDefendersSiegeStart(owner, level);
        notifyAttackersSiegeStart(level);

        ClaimEvents.sendVillagersHome(level, this);
    }

    private void endSiege(RecruitsFaction owner, ServerLevel level) {
        notifyDefendersSiegeFailed(owner, level);
        notifyAttackersSiegeFailed(level);
    }

    private void notifyDefendersSiegeStart(RecruitsFaction owner, ServerLevel level) {
        Component msg = SIEGE_START_DEFENDER(getName(), getAttackingParties().toString());

        for (Player player : getPlayersOfFaction(owner, level)) {
            player.sendSystemMessage(msg);
        }
    }

    private void notifyAttackersSiegeStart(ServerLevel level) {
        Component msg = SIEGE_START_ATTACKER(getName());

        for (RecruitsFaction attacker : getAttackingParties()) {
            for (Player player : getPlayersOfFaction(attacker, level)) {
                player.sendSystemMessage(msg);
            }
        }
    }
    private void notifyDefendersSiegeFailed(RecruitsFaction owner, ServerLevel level) {
        Component msg = SIEGE_FAILED_DEFENDER(getName());

        for (Player player : getPlayersOfFaction(owner, level)) {
            player.sendSystemMessage(msg);
        }
    }

    private void notifyAttackersSiegeFailed(ServerLevel level) {
        Component msg = SIEGE_FAILED_ATTACKER(getName());

        for (RecruitsFaction attacker : getAttackingParties()) {
            for (Player player : getPlayersOfFaction(attacker, level)) {
                player.sendSystemMessage(msg);
            }
        }
    }

    public void addParty(List<RecruitsFaction> list, RecruitsFaction recruitsFaction) {
        if(recruitsFaction == null) return;

        if(!list.isEmpty()){
            for(RecruitsFaction attacker : list){
                if(attacker != null && attacker.getStringID().equals(recruitsFaction.getStringID())) return;
            }
        }

        list.add(recruitsFaction);
    }


    private List<RecruitsFaction> getAttackingParties() {
        return attackingParties == null ? Collections.emptyList() : attackingParties;
    }
    private List<ServerPlayer> getPlayersOfFaction(RecruitsFaction faction, ServerLevel level) {
        return FactionEvents.recruitsFactionManager
                .getPlayersInTeam(faction.getStringID(), level);
    }

    public Component SIEGE_START_ATTACKER(String claim){
        return Component.translatable("chat.recruits.text.siegeStartAttacker", claim).withStyle(ChatFormatting.GOLD);
    }
    public Component SIEGE_START_DEFENDER(String claim, String attackers){
        return Component.translatable("chat.recruits.text.siegeStartDefender", claim, attackers).withStyle(ChatFormatting.GOLD);
    }

    public Component SIEGE_FAILED_ATTACKER(String claim){
        return Component.translatable("chat.recruits.text.siegeFailedAttacker", claim).withStyle(ChatFormatting.GOLD);
    }

    public Component SIEGE_FAILED_DEFENDER(String claim){
        return Component.translatable("chat.recruits.text.siegeFailedDefender", claim).withStyle(ChatFormatting.GOLD);
    }
    public Component SIEGE_SUCCESS_ATTACKER(String claim){
        return Component.translatable("chat.recruits.text.siegeSuccessAttacker", claim).withStyle(ChatFormatting.GOLD);
    }

    public Component SIEGE_SUCCESS_DEFENDER(String claim){
        return Component.translatable("chat.recruits.text.siegeSuccessDefender", claim).withStyle(ChatFormatting.GOLD);
    }
}
